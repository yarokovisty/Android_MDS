package com.example.lab21

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.CountDownTimer
import android.os.IBinder
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat


class TimerService : Service() {

    private var timer: CountDownTimer? = null
    private val notificationId = 1
    private val channelId = "timer_channel"

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val minutes = intent?.getIntExtra("minutes", 0) ?: 0
        val seconds = intent?.getIntExtra("seconds", 0) ?: 0
        val totalTimeMillis = (minutes * 60 + seconds) * 1000L

        timer?.cancel()
        timer = object : CountDownTimer(totalTimeMillis, 1000) {
            @SuppressLint("DefaultLocale")
            override fun onTick(millisUntilFinished: Long) {
                val minutesLeft = millisUntilFinished / 60000
                val secondsLeft = (millisUntilFinished % 60000) / 1000
                val timeLeft = String.format("%02d:%02d", minutesLeft, secondsLeft)

                val notification = createNotification(timeLeft)
                startForeground(notificationId, notification)

                val updateIntent = Intent("TIMER_UPDATE")
                updateIntent.putExtra("time_left", timeLeft)
                sendBroadcast(updateIntent)
            }

            override fun onFinish() {
                stopSelf()
                val updateIntent = Intent("TIMER_FINISH")
                sendBroadcast(updateIntent)
            }
        }
        timer?.start()


        return START_NOT_STICKY
    }

    override fun onDestroy() {
        timer?.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun createNotificationChannel() {
        val channel = NotificationChannel(channelId, "Timer Channel", NotificationManager.IMPORTANCE_LOW)
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(channel)
    }

    private fun createNotification(timeLeft: String): Notification {
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Timer")
            .setContentText("Time remaining: $timeLeft")
            .setSmallIcon(R.drawable.icon_timer)
            .build()
    }
}