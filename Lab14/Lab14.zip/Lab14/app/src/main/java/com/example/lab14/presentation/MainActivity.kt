package com.example.lab14.presentation

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.lab14.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}