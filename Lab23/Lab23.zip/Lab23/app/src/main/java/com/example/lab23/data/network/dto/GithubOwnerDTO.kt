package com.example.lab23.data.network.dto

data class GithubOwnerDTO(
    val login: String
)