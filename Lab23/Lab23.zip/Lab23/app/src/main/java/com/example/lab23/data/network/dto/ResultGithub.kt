package com.example.lab23.data.network.dto

data class ResultGithub(
    val items: List<GithubDTO>
)
