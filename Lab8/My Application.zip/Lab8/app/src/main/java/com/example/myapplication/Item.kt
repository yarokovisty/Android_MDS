package com.example.myapplication

data class Item(
    val resId: Int,
    val food: Boolean
)
